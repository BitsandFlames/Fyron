FYRON CURATE - SYNTHETIC DEMO IMAGES

12 PNG images generated from mathematical ellipses and seeded noise.
No patient images, clinical identifiers, or external source images are included.
These phantoms illustrate the review workflow only. They are not anatomically
validated, diagnostic images, or a benchmark for medical image quality.

1. Launch Fyron Curate: fyron curate --open
2. Unzip this archive, create a cohort, and select the images/ folder.
3. Use this selection context:
   Synthetic demo only. Accept complete, clearly visible phantoms.
   Reject examples with severe noise, clipping, or low contrast.
4. Explicitly review every sample with A (accept) or D (reject).
5. Export CSV labels or create a clean folder of accepted originals.

The documentation screenshots use demo_03, demo_07, and demo_11 as rejected
examples; the other nine are accepted. These are illustrative choices only.
Images initially appear accepted in Curate; confirm each decision before CSV export.

Reproduce: install numpy and Pillow >= 10.1, then run python generate.py.
Created for Fyron documentation. Distributed under Fyron's MIT license.
