"""Create deterministic geometric phantoms for the Fyron Curate documentation.
Requires numpy and Pillow. These are illustrations, not clinical reference data.
"""
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
IMAGES = ROOT / 'images'
IMAGES.mkdir(exist_ok=True)
y, x = np.mgrid[-1:1:512j, -1:1:512j]

def ellipse(cx, cy, rx, ry, angle=0):
    t = np.deg2rad(angle)
    xx = (x-cx)*np.cos(t) + (y-cy)*np.sin(t)
    yy = -(x-cx)*np.sin(t) + (y-cy)*np.cos(t)
    return (xx/rx)**2 + (yy/ry)**2 <= 1

for i in range(1, 13):
    rng = np.random.default_rng(20261021+i)
    view = ['axial','coronal','sagittal'][(i-1)//4]
    a = np.zeros_like(x)
    if view == 'axial':
        specs = [(0,0,.81,.62,0,.65), (0,0,.76,.57,0,.39),
                 (-.29,-.10,.29,.32,-12,.13), (.29,-.10,.29,.32,12,.13),
                 (-.29,-.10,.24,.27,-12,.08), (.29,-.10,.24,.27,12,.08),
                 (0,.27,.12,.12,0,.85), (0,.27,.06,.06,0,.32),
                 (.05,.02,.17,.20,15,.58), (-.1,-.32,.065,.055,0,.76)]
    elif view == 'coronal':
        specs = [(0,0,.55,.87,0,.64), (0,0,.50,.82,0,.40),
                 (-.23,-.27,.19,.34,-8,.09), (.23,-.27,.19,.34,8,.09),
                 (0,.10,.065,.66,0,.80), (0,.10,.025,.61,0,.45),
                 (-.19,.34,.18,.23,-15,.54), (.25,.32,.13,.18,15,.57),
                 (-.18,.68,.09,.14,0,.77), (.18,.68,.09,.14,0,.77)]
    else:
        specs = [(0,0,.48,.85,-5,.65), (0,0,.43,.79,-5,.39),
                 (-.10,-.26,.25,.32,7,.09), (.20,.08,.07,.61,-8,.82),
                 (.20,.08,.027,.55,-8,.42), (-.12,.34,.22,.27,-10,.55),
                 (-.02,-.71,.19,.13,0,.67), (.06,.68,.18,.11,0,.73)]
    scale = 1 + (i%4-1.5)*.025
    for cx,cy,rx,ry,ang,val in specs:
        a[ellipse(cx,cy,rx*scale,ry*scale,ang)] = val
    mask = a>0
    a += mask*(.012*np.sin(x*43+y*25) + rng.normal(0,.012,a.shape))
    if i == 3:
        a += mask*rng.normal(0,.16,a.shape)
    if i == 7:
        a[x>.18] = 0
    if i == 11:
        a[mask] = .15 + .12*a[mask]
    grey = np.uint8(np.clip(a,0,1)*255)
    im = Image.fromarray(grey).convert('RGB')
    draw = ImageDraw.Draw(im)
    # Pillow's bundled font keeps this generator portable.
    font = ImageFont.load_default(size=16)
    small = ImageFont.load_default(size=13)
    draw.text((18,12), 'SYNTHETIC PHANTOM', font=small, fill=(168,174,184))
    draw.text((18,474), f'DEMO {i:02d}  /  {view.upper()}', font=font, fill=(225,229,236))
    draw.text((18,495), 'Geometric illustration - no patient data', font=ImageFont.load_default(size=10), fill=(120,127,139))
    im.save(IMAGES/f'demo_{i:02d}_{view}.png', optimize=True)

readme = '''FYRON CURATE - SYNTHETIC DEMO IMAGES

12 PNG images generated from mathematical ellipses and seeded noise.
No patient images, clinical identifiers, or external source images are included.
These phantoms illustrate the review workflow only. They are not anatomically
validated, diagnostic images, or a benchmark for medical image quality.

1. Launch Fyron Curate: fyron curate --open
2. Unzip this archive, create a cohort, and select the images/ folder.
3. Use this selection context:
   Synthetic demo only. Accept complete, clearly visible phantoms.
   Reject examples with severe noise, clipping, or low contrast.
4. Explicitly review every sample with A (accept) or D (reject).
5. Export CSV labels or create a clean folder of accepted originals.

The documentation screenshots use demo_03, demo_07, and demo_11 as rejected
examples; the other nine are accepted. These are illustrative choices only.
Images initially appear accepted in Curate; confirm each decision before CSV export.

Reproduce: install numpy and Pillow >= 10.1, then run python generate.py.
Created for Fyron documentation. Distributed under Fyron's MIT license.
'''
(ROOT/'README.txt').write_text(readme)
print('Created 12 synthetic PNGs in', IMAGES)
